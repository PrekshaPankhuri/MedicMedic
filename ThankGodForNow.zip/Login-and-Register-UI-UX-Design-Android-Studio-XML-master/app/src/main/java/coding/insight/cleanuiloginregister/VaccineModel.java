package coding.insight.cleanuiloginregister;

public class VaccineModel {

    String Name,Address,City,VaccineCentre,Number;

    public String getName() {
        return Name;
    }

    public String getAddress() {
        return Address;
    }

    public String getCity() {
        return City;
    }

    public String getVaccineCentre() {
        return VaccineCentre;
    }

    public String getNumber() {
        return Number;
    }
}
