package coding.insight.cleanuiloginregister;

public class BloodModel {

    String Name,Address,City,Number,BloodBank;

    public String getName() {
        return Name;
    }

    public String getAddress() {
        return Address;
    }

    public String getCity() {
        return City;
    }

    public String getNumber() {
        return Number;
    }

    public String getBloodBank() {
        return BloodBank;
    }
}
